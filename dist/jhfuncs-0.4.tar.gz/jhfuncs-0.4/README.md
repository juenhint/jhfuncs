# jhfuncs
jhfuncs 0.4
A collection of bioinformatics tools for python utilizing pandas dataframes
Until published, install by running:
# python setup.py sdist bdist_wheel
# python setup.py build
# python setup.py install
# pip install .

Author: Hintikka, Jukka. jukka.e.hintikka@jyu.fi
