from setuptools import setup, find_packages

setup(name='jhfuncs',
version='0.4',
description='Tools for dataframe handling and analysis',
url='#',
author='Jukka Hintikka',
author_email='juenhint@jyu.fi',
license='MIT',
packages=find_packages(),
zip_safe=False)